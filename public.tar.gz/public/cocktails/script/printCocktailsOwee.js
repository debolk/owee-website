var cocktailArray = [
    ak47,
    apekop,
    b52,
    bananenBoner,
    cinderella,
    fireball,
    grandCafeMalibu,
    nysa,
    ogd,
    orangeTea,
    paarseMoederneuker,
    roelofZonderPassie,
    slappeSlet,
    stoplicht,
    tequillaSunrise,
    ubotter
];

var staticArray = cocktailArray;
printToWebpage(cocktailArray);