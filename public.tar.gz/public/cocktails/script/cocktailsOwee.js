//volume van glazen in mililiter
var volShotglas = 40;
var volLongdrink = 300;
var volSocial = 500;
var volTumbler = volLongdrink;

//prijzen van fris in euro
var prijsFrisGroot = 0.80;
var prijsFrisKlein = 1.00;

//namen van glazen
var longdrink = "Longdrink";
var social = "Social";
var tumbler = "Tumbler";
var shot = "Shot"


//function die het volume alcohol van één borrel van een cocktail returned
function calcAlcVol(sterk, hoeveelheidshotjes){
	return sterk.alcper * hoeveelheidshotjes * volShotglas / 100;
}

function calcAlcVolBier(aantal){
	return Dommelsch.alcper * aantal * 250 / 100;
}

//functie die het alcoholpercentage van een cocktail uitrekend
function calcAlcPer(volume, volumeglass){
	var alcoholPercentage = 100 * volume / volumeglass;
	return alcoholPercentage.toFixed(1);
}

//berekent de prijs van een borrelsterk
function calcPriceShot(sterk, hoeveelheidshotjes){
	return sterk.prijs * hoeveelheidshotjes;
}

//constructor voor een cocktail
function Cocktail(naam, glas, fris, spirits, alcper, prijs, creator, omschrijving){
	this.naam = naam;
	this.glass = glas;
	this.fris = fris;
	this.spirits = spirits;
	this.alcper = alcper;
	this.prijs = prijs;
	this.creator = creator;
	this.omschrijving = omschrijving;
}

var apekop = new Cocktail(
	"Apekop",
	shot,
	null,
	[[0.5, Dropshot.naam],[0.5, PisangAmbon.naam]],
	calcAlcPer(calcAlcVol(Dropshot, 0.5) + calcAlcVol(PisangAmbon, 0.5), volShotglas),
	1.50,
	null,
	"Serveren met een apekop snoepje"
);

var ak47 = new Cocktail(
    "AK-47", 
    shot, 
    null, 
    [[0.33, Dropshot.naam], [0.33, CafeMarakesh.naam], [0.33, Stroh80.naam]],
	calcAlcPer(calcAlcVol(Dropshot, 0.33) + calcAlcVol(CafeMarakesh, 0.33) + calcAlcVol(Stroh80, 0.33), volShotglas),
	2,
    null, 
    null
);

var b52 = new Cocktail(
    "B52", 
    shot, 
    null, 
    [[0.33, Baileys.naam], [0.33, CafeMarakesh.naam], [0.33, GrandManier.naam]],
	calcAlcPer(calcAlcVol(Baileys, 0.33) + calcAlcVol(CafeMarakesh, 0.33) + calcAlcVol(GrandManier, 0.33), volShotglas),
	2.50,
    null, 
    null
);

var bananenBoner = new Cocktail(
    "Bananenboner", 
    longdrink, 
    "Bananensap", 
    [[1, Blueberry.naam], [1, Passoa.naam]],
	calcAlcPer(calcAlcVol(Blueberry, 1) + calcAlcVol(Passoa, 1), volLongdrink),
	4, 
    null, 
    null);


var cinderella = new Cocktail(
	"Cinderella",
	longdrink,
	"Sprite",
	[[3, "Tonic"]],
	0,
	1.50,
	null,
	"Aanvullen met een scheutje grenadine en citroensap"
)

var fireball = new Cocktail(
    "Fireball", 
    shot, 
    null, 
    [[0.33, Sambuca.naam], [0.67, Goldstrike.naam]],
	calcAlcPer(calcAlcVol(Sambuca,0.33) + calcAlcVol(Goldstrike, 0.67), volShotglas),
	2.50, 
    null, 
    null
);

var grandCafeMalibu = new Cocktail(
    "Grand Cafe Malibu", 
    longdrink, 
    "Chocomel", 
    [[0.5, GrandManier.naam], [0.5, CafeMarakesh.naam], [1, Malibu.naam]],
	calcAlcPer(calcAlcVol(GrandManier, 0.5) + calcAlcVol(CafeMarakesh, 0.5) + calcAlcVol(Malibu, 1), volLongdrink),
	4, 
    null, 
    null
);

var nysa = new Cocktail(
    "Nysa",
    tumbler,
    "Sinas",
    [[0.5, BlueCuracao.naam],[0.5, Ketel1.naam]],
    calcAlcPer(calcAlcVol(BlueCuracao, 0.5) + calcAlcVol(Ketel1, 0.5), volTumbler),
    2.50,
    null,
    "Serveren met een bananensnoepje in het glas"
)

var ogd = new Cocktail(
    "OGD", 
    longdrink, 
    "Ginger Ale", 
    [[1, Oranjebitter.naam], [1, Disaronno.naam]],
	calcAlcPer(calcAlcVol(Oranjebitter, 1) + calcAlcVol(Disaronno, 1), volTumbler),
	3.50,
    null, 
    null
);

var orangeTea = new Cocktail(
    "Orange Tea",
    longdrink,
    "Ice Tea Green",
    [[1, "Sinaasappelsap"]],
    0,
    1.50,
    null,
    "Aanvullen met een scheutje grenadine en een parasoletje"
)

var paarseMoederneuker = new Cocktail(
    "Paarse moederneuker", 
    longdrink, 
    "Cassis", 
    [[0.5, BlueCuracao.naam], [0.5, Coebergh.naam], [0.5, GordonsGin.naam], [0.5, SmirrnoffVodka.naam]],
	calcAlcPer(calcAlcVol(Coebergh, 0.5) + calcAlcVol(BlueCuracao, 0.5) + calcAlcVol(GordonsGin, 0.5) + calcAlcVol(SmirrnoffVodka, 0.5), volLongdrink),
	4, 
    null, 
    null
);

var roelofZonderPassie = new Cocktail(
    "Roelof zonder passie",
    social,
    "AA Drink",
    [],
    0,
    2.50,
    null,
    "Aanvullen met half sinasappelsap en half appelsap"
);

var slappeSlet = new Cocktail(
    "Slappe Slet", 
    longdrink, 
    "Sprite", 
    [[0.5, Kontiki.naam], [0.5, VodkaRood.naam]],
	calcAlcPer(calcAlcVol(Kontiki, 0.5) + calcAlcVol(VodkaRood, 0.5), volLongdrink),
	2.50, 
    null, 
    null
);

var stoplicht = new Cocktail(
    "Stoplicht", 
    longdrink, 
    "Sinasappelsap", 
    [[0.5, PisangAmbon.naam], [0.5, Coebergh.naam]],
	calcAlcPer(calcAlcVol(PisangAmbon, 0.5) + calcAlcVol(Coebergh, 0.5), volLongdrink),
	3.00, 
    null, 
    null
);

var tequillaSunrise = new Cocktail(
    "Tequilla Sunrise",
    longdrink,
    "Sinaasappelsap",
    [[1, Tequila.naam]],
    calcAlcPer(calcAlcVol(Tequila,1), volLongdrink),
    3,
    null,
    "Aanvullen met grenadine"
);

var ubotter = new Cocktail(
    "U-Botter", 
    tumbler, 
    "Bitter Lemon", 
    [[0.33, PisangAmbon.naam], [0.33, TiaMaria.naam], [0.33, Jameson.naam]],
	calcAlcPer(calcAlcVol(PisangAmbon, 0.33) + calcAlcVol(TiaMaria, 0.33) + calcAlcVol(Jameson, 0.33), volTumbler),
	3,
    null, 
    null
);
