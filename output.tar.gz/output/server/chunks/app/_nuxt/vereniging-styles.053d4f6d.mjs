const vereniging_vue_vue_type_style_index_0_lang = "#vereniging{background-color:#e8ffb0;color:#068b8c;font-family:Bierstadt Bold;padding:100px 0;position:relative}#vereniging h2{color:#068b8c!important}";

const verenigingStyles_053d4f6d = [vereniging_vue_vue_type_style_index_0_lang, vereniging_vue_vue_type_style_index_0_lang];

export { verenigingStyles_053d4f6d as default };
//# sourceMappingURL=vereniging-styles.053d4f6d.mjs.map
