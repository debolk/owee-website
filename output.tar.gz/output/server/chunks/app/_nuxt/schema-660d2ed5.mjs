import { useSSRContext, mergeProps, unref } from 'vue';
import { u as useCookie } from './cookie-0c62e30a.mjs';
import { ssrRenderAttrs, ssrRenderClass, ssrInterpolate, ssrRenderComponent, ssrRenderAttr, ssrRenderList, ssrRenderStyle } from 'vue/server-renderer';
import { useMq } from 'vue3-mq';
import 'cookie-es';
import 'h3';
import 'destr';
import 'ohash';
import '../server.mjs';
import 'ofetch';
import 'hookable';
import 'unctx';
import 'vue-router';
import 'ufo';
import '@unhead/ssr';
import 'unhead';
import '@unhead/shared';
import 'vue3-smooth-scroll';
import 'defu';
import '../../nitro/node-server.mjs';
import 'node-fetch-native/polyfill';
import 'node:http';
import 'node:https';
import 'unenv/runtime/fetch/index';
import 'scule';
import 'klona';
import 'unstorage';
import 'radix3';
import 'node:fs';
import 'node:url';
import 'pathe';
import 'http-graceful-shutdown';

/**
 * fitty v2.3.7 - Snugly resizes text to fit its parent container
 * Copyright (c) 2023 Rik Schennink <rik@pqina.nl> (https://pqina.nl/)
 */

var e=function(e){if(e){var t=function(e){return [].slice.call(e)},n=0,i=1,r=2,o=3,a=[],l=null,u="requestAnimationFrame"in e?function(){e.cancelAnimationFrame(l),l=e.requestAnimationFrame((function(){return s(a.filter((function(e){return e.dirty&&e.active})))}));}:function(){},c=function(e){return function(){a.forEach((function(t){return t.dirty=e})),u();}},s=function(e){e.filter((function(e){return !e.styleComputed})).forEach((function(e){e.styleComputed=m(e);})),e.filter(y).forEach(v);var t=e.filter(p);t.forEach(d),t.forEach((function(e){v(e),f(e);})),t.forEach(S);},f=function(e){return e.dirty=n},d=function(e){e.availableWidth=e.element.parentNode.clientWidth,e.currentWidth=e.element.scrollWidth,e.previousFontSize=e.currentFontSize,e.currentFontSize=Math.min(Math.max(e.minSize,e.availableWidth/e.currentWidth*e.previousFontSize),e.maxSize),e.whiteSpace=e.multiLine&&e.currentFontSize===e.minSize?"normal":"nowrap";},p=function(e){return e.dirty!==r||e.dirty===r&&e.element.parentNode.clientWidth!==e.availableWidth},m=function(t){var n=e.getComputedStyle(t.element,null);return t.currentFontSize=parseFloat(n.getPropertyValue("font-size")),t.display=n.getPropertyValue("display"),t.whiteSpace=n.getPropertyValue("white-space"),!0},y=function(e){var t=!1;return !e.preStyleTestCompleted&&(/inline-/.test(e.display)||(t=!0,e.display="inline-block"),"nowrap"!==e.whiteSpace&&(t=!0,e.whiteSpace="nowrap"),e.preStyleTestCompleted=!0,t)},v=function(e){e.element.style.whiteSpace=e.whiteSpace,e.element.style.display=e.display,e.element.style.fontSize=e.currentFontSize+"px";},S=function(e){e.element.dispatchEvent(new CustomEvent("fit",{detail:{oldValue:e.previousFontSize,newValue:e.currentFontSize,scaleFactor:e.currentFontSize/e.previousFontSize}}));},h=function(e,t){return function(){e.dirty=t,e.active&&u();}},w=function(e){return function(){a=a.filter((function(t){return t.element!==e.element})),e.observeMutations&&e.observer.disconnect(),e.element.style.whiteSpace=e.originalStyle.whiteSpace,e.element.style.display=e.originalStyle.display,e.element.style.fontSize=e.originalStyle.fontSize;}},b=function(e){return function(){e.active||(e.active=!0,u());}},z=function(e){return function(){return e.active=!1}},F=function(e){e.observeMutations&&(e.observer=new MutationObserver(h(e,i)),e.observer.observe(e.element,e.observeMutations));},g={minSize:16,maxSize:512,multiLine:!0,observeMutations:"MutationObserver"in e&&{subtree:!0,childList:!0,characterData:!0}},W=null,E=function(){e.clearTimeout(W),W=e.setTimeout(c(r),x.observeWindowDelay);},M=["resize","orientationchange"];return Object.defineProperty(x,"observeWindow",{set:function(t){var n="".concat(t?"add":"remove","EventListener");M.forEach((function(t){e[n](t,E);}));}}),x.observeWindow=!0,x.observeWindowDelay=100,x.fitAll=c(o),x}function C(e,t){var n=Object.assign({},g,t),i=e.map((function(e){var t=Object.assign({},n,{element:e,active:!0});return function(e){e.originalStyle={whiteSpace:e.element.style.whiteSpace,display:e.element.style.display,fontSize:e.element.style.fontSize},F(e),e.newbie=!0,e.dirty=!0,a.push(e);}(t),{element:e,fit:h(t,o),unfreeze:b(t),freeze:z(t),unsubscribe:w(t)}}));return u(),i}function x(e){var n=arguments.length>1&&void 0!==arguments[1]?arguments[1]:{};return "string"==typeof e?C(t(document.querySelectorAll(e)),n):C([e],n)[0]}}(null);const fitty = e;

const programma = {
  maandag: {
    begintijd: 1700,
    planning: [
      {
        titel: {
          dutch: "Pimp je Fiets",
          english: "Pimp my Bike"
        },
        start: 1700,
        end: 1800,
        beschrijving: {
          dutch: "Is jouw nieuwe (of oude) fiets ook nog zo saai en lastig herkenbaar? Geef hem wat flair met verf, stickers, googly eyes (!) en een gezonde hoeveelheid glitters. Niemand die jouw fiets nog durft te stelen, en jij hoeft je geen zorgen meer te maken dat je hem niet kan vinden in de overvolle fietsenstalling.",
          english: "Is your new (or old) bike boring or difficult to find? Here you can pimp your bike using an assortment of awesome decorations like paint, stickers, googly eyes (!) and a healthy amount of glitter. No one will ever dare to steal your bike again and you don\u2019t have to worry about losing it anymore."
        },
        lokatie: "links"
      },
      {
        titel: {
          dutch: "Kinky knopen",
          english: "Kinky knots"
        },
        start: 1700,
        end: 1800,
        beschrijving: {
          dutch: "Leer van schippers en maten van onze botter Trui nieuwe knopen en strikken. Te gebruiken aan boord van Trui, of voor ... andere doeleinden...",
          english: "Learn new knots and bows from the skippers and mates or our boat Trui. Usable on board of Trui, or for ... other purposes..."
        },
        lokatie: "rechts"
      },
      {
        titel: {
          dutch: "Eten @Bolk",
          english: "Dinner @Bolk"
        },
        start: 1800,
        end: 1930,
        beschrijving: {
          dutch: "Eten bij de Bolk is echt mega lekker en gazellig, kom lekker eten!",
          english: "Dinner with the Bolk is really good, come and have a good meal!"
        },
        lokatie: "midden"
      },
      {
        titel: {
          dutch: "Weerwolven",
          english: "Werewolves"
        },
        start: 1930,
        end: 2100,
        beschrijving: {
          dutch: "Speel met bolkers One Night Weerwolven, een bliksemsnelle en meer interactieve versie van het orginele Weerwolven.",
          english: "Play One Night Werewolves with us, a lightning fast and more interactive versie of the original Werewolves."
        },
        lokatie: "links"
      },
      {
        titel: {
          dutch: "Badeendjes vissen",
          english: "Rubber Duck fishing"
        },
        start: 2e3,
        end: 2200,
        beschrijving: {
          dutch: "Om een BADEENDfeest te houden moeten we wel badeendjes hebben. Help ons ze op te vissen!",
          english: "We need rubber ducks to hold a RUBBER DUCK party. Help us fish them!"
        },
        lokatie: "rechts"
      },
      {
        titel: {
          dutch: "Preimeppen",
          english: "Leek whopping"
        },
        start: 2100,
        end: 2130,
        beschrijving: {
          dutch: "Wat zou jij doen als je tientallen kilo\u2019s prei rond hebt slingeren? Kapot slaan tegen je medestudenten natuurlijk! Kom naar de Bolk, claim je prei en verlies een aantal vrienden in dit geweldige idee wat nooit fout kan gaan.",
          english: "What would you do in case you have access to tens of kilos of leek? Hit your fellow students of course! Visit the Bolk, claim your leek and lose a couple of friends during this awesome idea that can\u2019t possibly go wrong."
        },
        lokatie: "links"
      },
      {
        titel: {
          dutch: "BADEENDfeest",
          english: "RUBBER DUCK party"
        },
        start: 2130,
        end: 400,
        beschrijving: {
          dutch: "",
          english: ""
        },
        lokatie: "midden"
      },
      {
        titel: {
          dutch: "4 uur cup-a-soup",
          english: "4 O' Clock cup-a-soup"
        },
        start: 400,
        end: 415,
        beschrijving: {
          dutch: "Beetje moe? Wil je je weer levend voelen, als herboren? Neem dan een 4 uur Cup-a-Soup, dat zouden meer mensen moeten doen!",
          english: "Tired after a long night? Wanna feel alive, like you were born again? Then enjoy a nice cup-a-soup!"
        },
        lokatie: "midden"
      }
    ]
  },
  dinsdag: {
    begintijd: 1700,
    planning: [
      {
        titel: {
          dutch: "Mega spellen",
          english: "Mega games"
        },
        start: 1700,
        end: 1800,
        beschrijving: {
          dutch: "Geven Vier op een rij en Jenga jou nostalgische gevoelens? Kom het spelen in het MEGA. Zorg ervoor dat je overwinning ook van een afstand te bewonderen is of daag je vrienden uit voor een rematch. Of probeer iets anders en ga spijkerslaan. Iedereen om een GROTE boomstronk, spijkers en hamers, dit kan alleen maar voor ENORM veel plezier zorgen!",
          english: "Do Connect Four and Jenga give you nostalgic feelings? Play it in MEGA. Make sure that your victory can also be admired from a distance or challenge your friends to a rematch. Or try something different and play Nail Stump. Everyone around a BIG tree stump, nails and hammers, this can only lead to a HUGE amount of fun!"
        },
        lokatie: "midden"
      },
      {
        titel: {
          dutch: "Eten @Bolk",
          english: "Dinner @Bolk"
        },
        start: 1800,
        end: 2e3,
        beschrijving: {
          dutch: "Eten bij de Bolk is echt mega lekker en gazellig, kom lekker eten!",
          english: "Dinner with the Bolk is really good, come and have a good meal!"
        },
        lokatie: "midden"
      },
      {
        titel: {
          dutch: "Mattenfort bouwen",
          english: "Build a Mat fort"
        },
        start: 2e3,
        end: 2200,
        beschrijving: {
          dutch: "Kom lekker een fort bouwen uit de matten uit het vooronder van onze botter Trui om op uit te rusten van alle heftige activiteiten.",
          english: "Come build a fort out of the mats from the forecastle from out boat Trui to relax from all the busy activities."
        },
        lokatie: "rechts"
      },
      {
        titel: {
          dutch: "Kijken hoe het Klinkt",
          english: "See how it Sounds"
        },
        start: 2100,
        end: 2200,
        beschrijving: {
          dutch: "Weet jij hoe een wasmachine klinkt als het van 4 meter valt op de grond? Kom er hier achter!",
          english: "Do you know what sound a washing machine makes when it falls 4 meters to the ground? Come and find out here!"
        },
        lokatie: "links"
      },
      {
        titel: {
          dutch: "Speciaalbier proeverij",
          english: "Craft beer tasting"
        },
        start: 2200,
        end: 2300,
        beschrijving: {
          dutch: "Bier is er in allerlei soorten en maten. Hou je van een zoet biertje of juist eentje met een bittertje? Wil jij dat je bier zonder toevoegingen is gemaakt, of vind je het niet erg als er peper in zit? Hou je van koffie en bier? Dan kan dat ook! Het Bolksch BierbrouwersGilde kan je er van alles over vertellen tijdens deze speciaalbierproeverij!",
          english: "Craft beers come in many shapes and sizes. Do you like a sweet or a bitter pint? Or don\u2019t you mind if it is brewed with pepper or coffee beans? The Bolksch BierbrouwersGilde (Craft Beer Brewing Guild of the Bolk) can tell you a ton of information with every sip you take."
        },
        lokatie: "links"
      },
      {
        titel: {
          dutch: "3D-Twister",
          english: "3D-Twister"
        },
        start: 2200,
        end: 2300,
        beschrijving: {
          dutch: "Twister is een veel te simpel en comfortabel spel. Om het wat interessanter te maken voegen we een extra dimensie toe, zo garanderen we dat iedereen in de knoop raakt!",
          english: "Twister is a far to simple and comfortable game. To make it more interesting, we\u013Al be adding an extra dimension. This way we can guarantee everyone gets in a bind!"
        },
        lokatie: "rechts"
      },
      {
        titel: {
          dutch: "Irish Hour",
          english: "Irish Hour"
        },
        start: 2300,
        end: 2400,
        beschrijving: {
          dutch: "Kom Guinness drinken, we hebben het op tap.",
          english: "Come drink Guinness, we've got it on tap."
        },
        lokatie: "links"
      },
      {
        titel: {
          dutch: "Retro gamen",
          english: "Retro gaming"
        },
        start: 2230,
        end: 2400,
        beschrijving: {
          dutch: "Ken jij je klassiekers nog? Daag je vrienden uit in een potje Mario Kart, Super Smash of andere spelletjes!",
          english: "Do you know your classics? Challenge your friends in a game of Mario Kart, Super Smash and many more games!"
        },
        lokatie: "rechts"
      },
      {
        titel: {
          dutch: "Karaoke",
          english: "Karaoke"
        },
        start: 2400,
        end: 400,
        beschrijving: {
          dutch: "Wil jij een hele avond de leukste nummers mee bl\xE8ren? Kom dan naar de karaoke en schreeuw de longen uit je lijf.",
          english: "Do you want to sing to all your favorite songs? Then go to the karaoke and sing till your throat hurts."
        },
        lokatie: "midden"
      },
      {
        titel: {
          dutch: "4 uur cup-a-soup",
          english: "4 O' Clock cup-a-soup"
        },
        start: 400,
        end: 415,
        beschrijving: {
          dutch: "Beetje moe? Wil je je weer levend voelen, als herboren? Neem dan een 4 uur Cup-a-Soup, dat zouden meer mensen moeten doen!",
          english: "Tired after a long night? Wanna feel alive, like you were born again? Then enjoy a nice cup-a-soup!"
        },
        lokatie: "midden"
      }
    ]
  },
  woensdag: {
    begintijd: 1700,
    planning: [
      {
        titel: {
          dutch: "DnD one shot",
          english: "DnD one shot"
        },
        start: 1700,
        end: 1900,
        beschrijving: {
          dutch: "We hebben veel enthousiaste DM\u2019s op de Bolk, die graag een leuke oneshot voor jullie neerzetten. Laat je met je groepje meenemen naar verre werelden en voel je vrij om op je eigen manier te roleplayen ^^",
          english: "We've got lots of enthousiastic DM's at the Bolk that would love to DM an oneshot for you. Come visit faraway worlds with your group and feel free to roleplay in your own way ^^."
        },
        lokatie: "midden"
      },
      {
        titel: {
          dutch: "Eten @Bolk",
          english: "Dinner @Bolk"
        },
        start: 1900,
        end: 2030,
        beschrijving: {
          dutch: "Eten bij de Bolk is echt mega lekker en gazellig, kom lekker eten!",
          english: "Dinner with the Bolk is really good, come and have a good meal!"
        },
        lokatie: "midden"
      },
      {
        titel: {
          dutch: "Botter Rossen",
          english: "Botter Ross Painting"
        },
        start: 2030,
        end: 2230,
        beschrijving: {
          dutch: "Schilder in de stijl van Bob Ross een scenisch landschap met onze botter Trui erin.",
          english: 'Paint in the style of Bob Ross a scenic landscape with our boat "Trui".'
        },
        lokatie: "midden"
      },
      {
        titel: {
          dutch: "Bierviltjesoorlog",
          english: "Coaster War"
        },
        start: 2230,
        end: 30,
        beschrijving: {
          dutch: "Tijdens een bierviltjesoorlog ga je met een net niet oneindige voorraad bierviltjes gooien. Gooi ze op je vrienden en/of je mentor. Alles is toegestaan in een bierviltjesoorlog. \u201CBierviltjes! Bierviltjes overal! Dit is chaos!\u201D - de enige overlevende vorig jaar",
          english: "During this event you will be able to throw a nearly unlimited supply of beer mats. Throw them at anyone.  \u201CBeer mats, Beer mats everywhere!\u201D - last years only survivor."
        },
        lokatie: "links"
      },
      {
        titel: {
          dutch: "Loco met Choco",
          english: "Loco with Choco"
        },
        start: 2230,
        end: 2330,
        beschrijving: {
          dutch: "Chocoladetaart, chocoladecake, chocoladekoekjes, chocoladecocktails, chocolademousse \u2026 Voor alle chocoladeliefhebbers hebben onze keukenprinsen en -prinsessen alles uit de kast gehaald om de meest chocola houdende baksels te cre\xEBren. Bestaat er iets als te veel chocola? Vind het uit!",
          english: "Chocolate cake, chocolate biscuits, chocolate cocktails, chocolate mousse \u2026 For all chocolate lovers our kitchen princes and princesses have tried to create the most chocolate-containing pastry. Is there something like too much chocolate? Find it out!"
        },
        lokatie: "rechts"
      },
      {
        titel: {
          dutch: "Blikbier Lingo",
          english: "Beer can Lingo"
        },
        start: 30,
        end: 130,
        beschrijving: {
          dutch: "Raad woorden en grabbel in de blikbierton om punten te verdienen. Groeeeeen!",
          english: "Guess the words and grab something in the ton of beer cans to get points. Greeeeeeeen!"
        },
        lokatie: "midden"
      },
      {
        titel: {
          dutch: "Blikbierkwartier",
          english: "Canned beer quarter"
        },
        start: 130,
        end: 230,
        beschrijving: {
          dutch: "Is dit een BlikBierBorrel? Wist je dat er een auto in de soos stond? Kom zuipen ofzo.",
          english: "Is this a CannedBeerDrink? Did you know there was a car in the soos? Come and drink or something."
        },
        lokatie: "midden"
      },
      {
        titel: {
          dutch: "DIY kapsalon",
          english: "DIY kapsalon"
        },
        start: 230,
        end: 400,
        beschrijving: {
          dutch: "Kom een kapsalon bouwen uit onze selectie van ingredi\xEBnten. Maak je kapsalon een perfecte creatie, of een vreemde combinatie van smaken die niet samen zouden moeten gaan.",
          english: "Come and build your own kapsalon from our selection of ingredients. Make it a perfect creation, or a weird combinatie of tastes that shouldn't go together."
        },
        lokatie: "midden"
      },
      {
        titel: {
          dutch: "4 uur cup-a-soup",
          english: "4 'O Clock cup-a-soup"
        },
        start: 400,
        end: 415,
        beschrijving: {
          dutch: "Beetje moe? Wil je je weer levend voelen, als herboren? Neem dan een 4 uur Cup-a-Soup, dat zouden meer mensen moeten doen!",
          english: "Tired after a long night? Wanna feel alive, like you were born again? Then enjoy a nice cup-a-soup!"
        },
        lokatie: "midden"
      }
    ]
  },
  donderdag: {
    begintijd: 1700,
    planning: [
      {
        titel: {
          dutch: "Spa",
          english: "Spa"
        },
        start: 1700,
        end: 1800,
        beschrijving: {
          dutch: "Ook zo moe van gisteren? Kom chillen met zwembadjes, gezichtscreme, gekoelde drankjes en je rustige zomerse muziek. ",
          english: "Tired from yesterday? Come chill out at our spa with kiddie pools, face masks, cooled drinks and summery tunes."
        },
        lokatie: "links"
      },
      {
        titel: {
          dutch: "VVThee",
          english: "VVTea"
        },
        start: 1700,
        end: 1800,
        beschrijving: {
          dutch: "Gezellige theeproeverij met de vereniging Vrienden Van Trui met lekkere hapjes!",
          english: "Cosy tea tasting with the association Friends of Trui (Vrienden Van Trui) with tast treats!"
        },
        lokatie: "rechts"
      },
      {
        titel: {
          dutch: "Band in de soos",
          english: "Band in the soos"
        },
        start: 2e3,
        end: 2300,
        beschrijving: {
          dutch: "De bands Headfirst en Staplers komen optreden in de soos. Dat gaat een fantastische performance worden!",
          english: "The bands Headfirst and Staplers will be performing here. It'll be a fantastic performance!"
        },
        lokatie: "midden"
      }
    ]
  }
};
const __default__$1 = {
  props: ["dag"],
  inject: ["mq"],
  data() {
    return {
      vandaag: programma[this.$props.dag].planning,
      modal: false,
      modalItem: {
        titel: {},
        beschrijving: {}
      }
    };
  },
  mounted() {
    fitty(".fitTitle", {
      minSize: 10,
      maxSize: 20,
      multiline: true
    });
    fitty(".fitTime", {
      minSize: 10,
      maxSize: 11,
      multiline: false
    });
  },
  computed: {
    grow() {
      return this.mq.mobile ? 1.4 : 1.4;
    },
    begintijd: function() {
      if (this.mq.mobile) {
        return programma[this.$props.dag].begintijd;
      }
      let s = Number.MAX_SAFE_INTEGER;
      for (let i in programma) {
        s = Math.min(programma[i].begintijd, s);
      }
      return s;
    }
  },
  methods: {
    openmodal(item) {
      this.modalItem = item;
      this.modal = true;
    },
    pad(n, width, z) {
      z = z || "0";
      n = n + "";
      return n.length >= width ? n : new Array(width - n.length + 1).join(z) + n;
    },
    timeToPx(time) {
      var b = new Date(0, 0, 0, Math.floor(this.begintijd / 100), this.begintijd % 100, 0);
      var d = 0;
      if (time < 1e3) {
        d = 1;
      }
      var t = new Date(0, 0, d, Math.floor(time / 100), time % 100, 0);
      var diff = Math.abs(b - t) / 6e4;
      return diff;
    }
  }
};
const _sfc_main$1 = /* @__PURE__ */ Object.assign(__default__$1, {
  __name: "programmas",
  __ssrInlineRender: true,
  setup(__props) {
    useMq();
    const language = useCookie("language", { maxAge: 100 * 24 * 60 * 60, default: () => {
      return "dutch";
    } });
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "programma" }, _attrs))}><div class="container"><div class="days"${ssrRenderAttr("id", __props.dag)}><!--[-->`);
      ssrRenderList(_ctx.vandaag, (item, index) => {
        _push(`<div style="${ssrRenderStyle({ height: `${Math.max((_ctx.timeToPx(item.end) - _ctx.timeToPx(item.start)) * _ctx.grow, 40)}px`, top: `${_ctx.timeToPx(item.start) * _ctx.grow}px` })}" class="${ssrRenderClass([{ "leftevent": item.lokatie === "links", "rightevent": item.lokatie === "rechts" }, "event"])}"><div class="textcontainer"><span class="title fitTitle">${ssrInterpolate(item.titel[unref(language)])}</span><br>`);
        if (!!item.neptijd) {
          _push(`<span class="time fitTime">${ssrInterpolate(`${item.nepstart} - ${item.nepend}`)}</span>`);
        } else {
          _push(`<span class="time fitTime">${ssrInterpolate(`${Math.floor(item.start / 100)}:${_ctx.pad(item.start % 100, 2)} - ${Math.floor(item.end / 100)}:${_ctx.pad(item.end % 100, 2)}`)}</span>`);
        }
        _push(`</div></div>`);
      });
      _push(`<!--]--></div></div><div class="${ssrRenderClass([{ "is-active": _ctx.modal }, "modal"])}"><div class="modal-background"></div><div class="modal-content"><div class="modaltitle">${ssrInterpolate(_ctx.modalItem.titel[unref(language)])}</div>`);
      if (!!_ctx.modalItem.neptijd) {
        _push(`<span class="time">${ssrInterpolate(`${_ctx.modalItem.nepstart} - ${_ctx.modalItem.nepend}`)}</span>`);
      } else {
        _push(`<span class="time">${ssrInterpolate(`${Math.floor(_ctx.modalItem.start / 100)}:${_ctx.pad(_ctx.modalItem.start % 100, 2)} - ${Math.floor(_ctx.modalItem.end / 100)}:${_ctx.pad(_ctx.modalItem.end % 100, 2)}`)}</span>`);
      }
      _push(`<br><p>${_ctx.modalItem.beschrijving[unref(language)]}</p></div><button class="modal-close is-large"></button></div></div>`);
    };
  }
});
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/programmas.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const programmas = _sfc_main$1;
const __default__ = {
  data() {
    return {
      dagen: {
        dutch: ["maandag", "dinsdag", "woensdag", "donderdag"],
        english: ["Monday", "Tuesday", "Wednesday", "Thursday"]
      }
    };
  },
  inject: ["mq"],
  components: {
    programmas
  }
};
const _sfc_main = /* @__PURE__ */ Object.assign(__default__, {
  __name: "schema",
  __ssrInlineRender: true,
  setup(__props) {
    const mq = useMq();
    const language = useCookie("language", { maxAge: 100 * 24 * 60 * 60, default: () => {
      return "dutch";
    } });
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({ id: "schema" }, _attrs))}><div class="content">`);
      if (unref(language) === "dutch") {
        _push(`<h2>WAT IS ER TE DOEN TIJDENS DE OWEE?</h2>`);
      } else {
        _push(`<!---->`);
      }
      if (unref(language) === "english") {
        _push(`<h2>WHAT IS THERE TO DO DURING THE OWEE?</h2>`);
      } else {
        _push(`<!---->`);
      }
      _push(`<div class="columns"><div class="column"><div class="columns"><div class="column"><div class="${ssrRenderClass([{ "mobiledagcontainerparent": unref(mq) === "mobile" }, "dagcontainer"])}"><h3>${ssrInterpolate(_ctx.dagen[unref(language)][0])}</h3>`);
      _push(ssrRenderComponent(programmas, {
        dag: "maandag",
        class: { "mobiledagcontainer": unref(mq) === "mobile" }
      }, null, _parent));
      _push(`</div></div><div class="column"><div class="${ssrRenderClass([{ "mobiledagcontainerparent": unref(mq) === "mobile" }, "dagcontainer"])}"><h3>${ssrInterpolate(_ctx.dagen[unref(language)][1])}</h3>`);
      _push(ssrRenderComponent(programmas, {
        dag: "dinsdag",
        class: { "mobiledagcontainer": unref(mq) === "mobile" }
      }, null, _parent));
      _push(`</div></div><div class="column"><div class="${ssrRenderClass([{ "mobiledagcontainerparent": unref(mq) === "mobile" }, "dagcontainer"])}"><h3>${ssrInterpolate(_ctx.dagen[unref(language)][2])}</h3>`);
      _push(ssrRenderComponent(programmas, {
        dag: "woensdag",
        class: { "mobiledagcontainer": unref(mq) === "mobile" }
      }, null, _parent));
      _push(`</div></div><div class="column"><div class="${ssrRenderClass([{ "mobiledagcontainerparent": unref(mq) === "mobile" }, "dagcontainer"])}"><h3>${ssrInterpolate(_ctx.dagen[unref(language)][3])}</h3>`);
      _push(ssrRenderComponent(programmas, {
        dag: "donderdag",
        class: { "mobiledagcontainer": unref(mq) === "mobile" }
      }, null, _parent));
      _push(`</div></div></div></div></div></div></div>`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/schema.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=schema-660d2ed5.mjs.map
