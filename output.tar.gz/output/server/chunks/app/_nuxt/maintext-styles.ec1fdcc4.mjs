const maintext_vue_vue_type_style_index_0_lang = "#main p{color:#fff;font-family:Bierstadt Bold}#main{background-color:#068b8c;padding:100px 0;position:relative}.video-container{border-radius:20px;height:0;overflow:hidden;padding-bottom:53%;padding-top:30px;position:relative}.video-container embed,.video-container iframe,.video-container object{height:100%;left:0;position:absolute;top:0;width:100%}";

const maintextStyles_ec1fdcc4 = [maintext_vue_vue_type_style_index_0_lang, maintext_vue_vue_type_style_index_0_lang];

export { maintextStyles_ec1fdcc4 as default };
//# sourceMappingURL=maintext-styles.ec1fdcc4.mjs.map
