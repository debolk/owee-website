const contact_vue_vue_type_style_index_0_lang = "#contact a,#contact p{color:#fff;font-family:Bierstadt Bold}#contact a{text-decoration:underline}#contact a:hover{color:#e8ffb0}#contact{align-items:center;background-color:#068b8c;min-height:600px;padding:100px 0;position:relative;text-align:center}.button2{background-color:none;border:none;height:auto;width:auto}.socials{display:inline-block}.floatleft{float:left}#contact iframe,.floatleft{display:inline;max-width:80vw;width:400px}#contact iframe{border:2px solid #e8ffb0!important;border-radius:10px;float:right}#contact .mobile{float:none!important;padding:50px 0!important}";

const contactStyles_993e2cb8 = [contact_vue_vue_type_style_index_0_lang, contact_vue_vue_type_style_index_0_lang];

export { contactStyles_993e2cb8 as default };
//# sourceMappingURL=contact-styles.993e2cb8.mjs.map
