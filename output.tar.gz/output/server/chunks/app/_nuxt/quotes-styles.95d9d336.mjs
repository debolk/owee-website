const quotes_vue_vue_type_style_index_0_lang = "#quotes{background-color:#e8ffb0;color:#e8ffb0;font-family:Bierstadt Bold;padding:100px 0;position:relative}.mobile-carousel .carousel__next,.mobile-carousel .carousel__prev{margin-left:20px;margin-right:20px}.carousel__next,.carousel__prev{border:none;margin-left:70px;margin-right:70px;min-height:30px;min-width:30px;z-index:5}.carousel{padding-left:110px;padding-right:110px}.mobile-carousel{padding-left:60px;padding-right:60px}.slide-container{background-color:#068b8c;font-weight:500;height:100%;margin:0 10px;padding:20px}.photo,.slide-container{border-radius:10px;width:100%}.photo{border:2px solid #e8ffb0;display:block;margin-bottom:10px;margin-left:auto;margin-right:auto;max-width:150px}";

const quotesStyles_95d9d336 = [quotes_vue_vue_type_style_index_0_lang, quotes_vue_vue_type_style_index_0_lang];

export { quotesStyles_95d9d336 as default };
//# sourceMappingURL=quotes-styles.95d9d336.mjs.map
