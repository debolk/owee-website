const navbar_vue_vue_type_style_index_0_lang = ".navbar{background-color:#068b8c}.navtitle{font-size:2rem!important;margin-top:8px;text-align:center;width:calc(100% - 3.25rem)}.flag{position:relative;top:6px;width:25px}.navbar-menu{background-color:#068b8c;border-bottom:2px solid #e8ffb0;padding:0;position:fixed;text-align:center;transition:all .2s ease;width:100%}.navmenusmall{top:-600px}.is-down{top:57px}.navbar-brand{border-bottom:5px solid #e8ffb0}.navbar-menu a{display:block;height:100%;width:100%}.menuitemcontainer{border-radius:10px;line-height:2.5;padding:0 20px;text-align:center;transition:all .2s ease}.menuitemcontainer:hover{background-color:#fff}.menuitemcontainer:hover a{color:#068b8c}.navbar a{color:#fff;font-family:Some Time Later;font-size:1.5rem}.navbar-brand img{bottom:7px;height:50px;position:relative}";

const navbarStyles_0bc3c0ec = [navbar_vue_vue_type_style_index_0_lang, navbar_vue_vue_type_style_index_0_lang];

export { navbarStyles_0bc3c0ec as default };
//# sourceMappingURL=navbar-styles.0bc3c0ec.mjs.map
