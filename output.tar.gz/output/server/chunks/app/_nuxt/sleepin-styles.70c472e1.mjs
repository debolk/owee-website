const sleepin_vue_vue_type_style_index_0_lang = "#sleepin h2{color:#068b8c!important}#sleepin p{color:#068b8c;font-family:Bierstadt Bold}#sleepin{background-color:#e8ffb0;padding:100px 0;position:relative}.button{display:block;margin-left:auto;margin-right:auto;width:150px}";

const sleepinStyles_70c472e1 = [sleepin_vue_vue_type_style_index_0_lang, sleepin_vue_vue_type_style_index_0_lang];

export { sleepinStyles_70c472e1 as default };
//# sourceMappingURL=sleepin-styles.70c472e1.mjs.map
