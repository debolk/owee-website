const sponsors_vue_vue_type_style_index_0_lang = "#sponsors{background-color:#e8ffb0;color:#068b8c;font-family:Bierstadt Bold;min-height:calc(70vh + 10px);padding:100px 0;position:relative}#sponsors .mobilesponsors{min-height:150vh!important}#sponsors h2{color:#068b8c!important}#sponsors .mobile{font-size:6.7vw;left:10vw!important;padding:10px 0!important}#link img.mobile{margin-top:40px;max-width:80vw;width:80vw!important}#link img{margin-left:auto;margin-right:auto;max-width:20vw;width:20vw}#link{font-size:2vw;position:absolute}.center.mobile{margin-top:80px}.center{left:40vw}.left{left:400px}.right{right:400px}.right.mobile{top:200vw!important}";

const sponsorsStyles_24007bc7 = [sponsors_vue_vue_type_style_index_0_lang, sponsors_vue_vue_type_style_index_0_lang];

export { sponsorsStyles_24007bc7 as default };
//# sourceMappingURL=sponsors-styles.24007bc7.mjs.map
