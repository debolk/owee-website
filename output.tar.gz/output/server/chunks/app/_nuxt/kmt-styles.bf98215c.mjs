const kmt_vue_vue_type_style_index_0_lang = "#kmt{background-color:#068b8c;color:#fff;font-family:Bierstadt Bold;padding:100px 0;position:relative}";

const kmtStyles_bf98215c = [kmt_vue_vue_type_style_index_0_lang, kmt_vue_vue_type_style_index_0_lang];

export { kmtStyles_bf98215c as default };
//# sourceMappingURL=kmt-styles.bf98215c.mjs.map
