const client_manifest = {
  "_cookie.1b8f798e.js": {
    "resourceType": "script",
    "module": true,
    "file": "cookie.1b8f798e.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "assets/facebook.svg": {
    "resourceType": "image",
    "mimeType": "image/svg+xml",
    "file": "facebook.bed82655.svg",
    "src": "assets/facebook.svg"
  },
  "assets/fotos/header.jpg": {
    "resourceType": "image",
    "mimeType": "image/jpeg",
    "file": "header.d616ff8f.jpg",
    "src": "assets/fotos/header.jpg"
  },
  "assets/instagram.svg": {
    "resourceType": "image",
    "mimeType": "image/svg+xml",
    "file": "instagram.aa9c1646.svg",
    "src": "assets/instagram.svg"
  },
  "assets/logo.svg": {
    "resourceType": "image",
    "mimeType": "image/svg+xml",
    "file": "logo.1e2073ca.svg",
    "src": "assets/logo.svg"
  },
  "assets/mwtransportservice.svg": {
    "resourceType": "image",
    "mimeType": "image/svg+xml",
    "file": "mwtransportservice.2cb1f7ac.svg",
    "src": "assets/mwtransportservice.svg"
  },
  "assets/netherlands.svg": {
    "resourceType": "image",
    "mimeType": "image/svg+xml",
    "file": "netherlands.e3f35579.svg",
    "src": "assets/netherlands.svg"
  },
  "assets/soos.svg": {
    "resourceType": "image",
    "mimeType": "image/svg+xml",
    "file": "soos.d27e01f3.svg",
    "src": "assets/soos.svg"
  },
  "assets/triangle-primary.svg": {
    "resourceType": "image",
    "mimeType": "image/svg+xml",
    "file": "triangle-primary.e81447b7.svg",
    "src": "assets/triangle-primary.svg"
  },
  "assets/triangle-secondary.svg": {
    "resourceType": "image",
    "mimeType": "image/svg+xml",
    "file": "triangle-secondary.ff209aed.svg",
    "src": "assets/triangle-secondary.svg"
  },
  "assets/united-kingdom.svg": {
    "resourceType": "image",
    "mimeType": "image/svg+xml",
    "file": "united-kingdom.1a55a5ce.svg",
    "src": "assets/united-kingdom.svg"
  },
  "assets/wikipedia.svg": {
    "resourceType": "image",
    "mimeType": "image/svg+xml",
    "file": "wikipedia.ebec8258.svg",
    "src": "assets/wikipedia.svg"
  },
  "assets/winenmore.svg": {
    "resourceType": "image",
    "mimeType": "image/svg+xml",
    "file": "winenmore.2620196f.svg",
    "src": "assets/winenmore.svg"
  },
  "layouts/default.vue": {
    "resourceType": "script",
    "module": true,
    "file": "default.8baafd94.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "layouts/default.vue"
  },
  "node_modules/@nuxt/ui-templates/dist/templates/error-404.css": {
    "resourceType": "style",
    "file": "error-404.7fc72018.css",
    "src": "node_modules/@nuxt/ui-templates/dist/templates/error-404.css"
  },
  "node_modules/@nuxt/ui-templates/dist/templates/error-404.vue": {
    "resourceType": "script",
    "module": true,
    "css": [],
    "file": "error-404.754a3648.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "node_modules/@nuxt/ui-templates/dist/templates/error-404.vue"
  },
  "error-404.7fc72018.css": {
    "file": "error-404.7fc72018.css",
    "resourceType": "style"
  },
  "node_modules/@nuxt/ui-templates/dist/templates/error-500.css": {
    "resourceType": "style",
    "file": "error-500.c5df6088.css",
    "src": "node_modules/@nuxt/ui-templates/dist/templates/error-500.css"
  },
  "node_modules/@nuxt/ui-templates/dist/templates/error-500.vue": {
    "resourceType": "script",
    "module": true,
    "css": [],
    "file": "error-500.969754d0.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "node_modules/@nuxt/ui-templates/dist/templates/error-500.vue"
  },
  "error-500.c5df6088.css": {
    "file": "error-500.c5df6088.css",
    "resourceType": "style"
  },
  "node_modules/nuxt/dist/app/entry.js": {
    "resourceType": "script",
    "module": true,
    "dynamicImports": [
      "layouts/default.vue",
      "node_modules/@nuxt/ui-templates/dist/templates/error-404.vue",
      "node_modules/@nuxt/ui-templates/dist/templates/error-500.vue"
    ],
    "file": "entry.b0830958.js",
    "isEntry": true,
    "src": "node_modules/nuxt/dist/app/entry.js",
    "_globalCSS": true
  },
  "pages/contact.css": {
    "resourceType": "style",
    "file": "contact.92b0844c.css",
    "src": "pages/contact.css"
  },
  "pages/contact.vue": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "instagram.aa9c1646.svg",
      "facebook.bed82655.svg",
      "wikipedia.ebec8258.svg"
    ],
    "css": [],
    "file": "contact.383d831b.js",
    "imports": [
      "_cookie.1b8f798e.js",
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/contact.vue"
  },
  "contact.92b0844c.css": {
    "file": "contact.92b0844c.css",
    "resourceType": "style"
  },
  "instagram.aa9c1646.svg": {
    "file": "instagram.aa9c1646.svg",
    "resourceType": "image",
    "mimeType": "image/svg+xml"
  },
  "facebook.bed82655.svg": {
    "file": "facebook.bed82655.svg",
    "resourceType": "image",
    "mimeType": "image/svg+xml"
  },
  "wikipedia.ebec8258.svg": {
    "file": "wikipedia.ebec8258.svg",
    "resourceType": "image",
    "mimeType": "image/svg+xml"
  },
  "pages/imageheader.css": {
    "resourceType": "style",
    "file": "imageheader.0d3eb0dd.css",
    "src": "pages/imageheader.css"
  },
  "pages/imageheader.vue": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "logo.1e2073ca.svg",
      "header.d616ff8f.jpg"
    ],
    "css": [],
    "file": "imageheader.3f5fb07c.js",
    "imports": [
      "_cookie.1b8f798e.js",
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/imageheader.vue"
  },
  "imageheader.0d3eb0dd.css": {
    "file": "imageheader.0d3eb0dd.css",
    "resourceType": "style"
  },
  "logo.1e2073ca.svg": {
    "file": "logo.1e2073ca.svg",
    "resourceType": "image",
    "mimeType": "image/svg+xml"
  },
  "header.d616ff8f.jpg": {
    "file": "header.d616ff8f.jpg",
    "resourceType": "image",
    "mimeType": "image/jpeg"
  },
  "pages/index.css": {
    "resourceType": "style",
    "file": "index.0b09dec0.css",
    "src": "pages/index.css"
  },
  "pages/index.vue": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "triangle-primary.e81447b7.svg",
      "triangle-secondary.ff209aed.svg",
      "soos.d27e01f3.svg"
    ],
    "css": [],
    "file": "index.a0a0bbd3.js",
    "imports": [
      "_cookie.1b8f798e.js",
      "node_modules/nuxt/dist/app/entry.js",
      "pages/imageheader.vue",
      "pages/quotes.vue",
      "pages/vereniging.vue",
      "pages/maintext.vue",
      "pages/schema.vue",
      "pages/sleepin.vue",
      "pages/kmt.vue",
      "pages/contact.vue",
      "pages/sponsors.vue",
      "pages/navbar.vue"
    ],
    "isDynamicEntry": true,
    "src": "pages/index.vue"
  },
  "index.0b09dec0.css": {
    "file": "index.0b09dec0.css",
    "resourceType": "style"
  },
  "triangle-primary.e81447b7.svg": {
    "file": "triangle-primary.e81447b7.svg",
    "resourceType": "image",
    "mimeType": "image/svg+xml"
  },
  "triangle-secondary.ff209aed.svg": {
    "file": "triangle-secondary.ff209aed.svg",
    "resourceType": "image",
    "mimeType": "image/svg+xml"
  },
  "soos.d27e01f3.svg": {
    "file": "soos.d27e01f3.svg",
    "resourceType": "image",
    "mimeType": "image/svg+xml"
  },
  "pages/kmt.css": {
    "resourceType": "style",
    "file": "kmt.79fc0cf0.css",
    "src": "pages/kmt.css"
  },
  "pages/kmt.vue": {
    "resourceType": "script",
    "module": true,
    "css": [],
    "file": "kmt.1120373b.js",
    "imports": [
      "_cookie.1b8f798e.js",
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/kmt.vue"
  },
  "kmt.79fc0cf0.css": {
    "file": "kmt.79fc0cf0.css",
    "resourceType": "style"
  },
  "pages/maintext.css": {
    "resourceType": "style",
    "file": "maintext.50b407da.css",
    "src": "pages/maintext.css"
  },
  "pages/maintext.vue": {
    "resourceType": "script",
    "module": true,
    "css": [],
    "file": "maintext.081757ae.js",
    "imports": [
      "_cookie.1b8f798e.js",
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/maintext.vue"
  },
  "maintext.50b407da.css": {
    "file": "maintext.50b407da.css",
    "resourceType": "style"
  },
  "pages/navbar.css": {
    "resourceType": "style",
    "file": "navbar.09967324.css",
    "src": "pages/navbar.css"
  },
  "pages/navbar.vue": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "united-kingdom.1a55a5ce.svg",
      "netherlands.e3f35579.svg"
    ],
    "css": [],
    "file": "navbar.3d4ec2cd.js",
    "imports": [
      "_cookie.1b8f798e.js",
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/navbar.vue"
  },
  "navbar.09967324.css": {
    "file": "navbar.09967324.css",
    "resourceType": "style"
  },
  "united-kingdom.1a55a5ce.svg": {
    "file": "united-kingdom.1a55a5ce.svg",
    "resourceType": "image",
    "mimeType": "image/svg+xml"
  },
  "netherlands.e3f35579.svg": {
    "file": "netherlands.e3f35579.svg",
    "resourceType": "image",
    "mimeType": "image/svg+xml"
  },
  "pages/quotes.css": {
    "resourceType": "style",
    "file": "quotes.bf0eb470.css",
    "src": "pages/quotes.css"
  },
  "pages/quotes.vue": {
    "resourceType": "script",
    "module": true,
    "css": [],
    "file": "quotes.6082aa74.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_cookie.1b8f798e.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/quotes.vue"
  },
  "quotes.bf0eb470.css": {
    "file": "quotes.bf0eb470.css",
    "resourceType": "style"
  },
  "pages/schema.css": {
    "resourceType": "style",
    "file": "schema.dc67ea1f.css",
    "src": "pages/schema.css"
  },
  "pages/schema.vue": {
    "resourceType": "script",
    "module": true,
    "css": [],
    "file": "schema.42848793.js",
    "imports": [
      "_cookie.1b8f798e.js",
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/schema.vue"
  },
  "schema.dc67ea1f.css": {
    "file": "schema.dc67ea1f.css",
    "resourceType": "style"
  },
  "pages/sleepin.css": {
    "resourceType": "style",
    "file": "sleepin.2a2fc065.css",
    "src": "pages/sleepin.css"
  },
  "pages/sleepin.vue": {
    "resourceType": "script",
    "module": true,
    "css": [],
    "file": "sleepin.68c282eb.js",
    "imports": [
      "_cookie.1b8f798e.js",
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/sleepin.vue"
  },
  "sleepin.2a2fc065.css": {
    "file": "sleepin.2a2fc065.css",
    "resourceType": "style"
  },
  "pages/sponsors.css": {
    "resourceType": "style",
    "file": "sponsors.5f5576a7.css",
    "src": "pages/sponsors.css"
  },
  "pages/sponsors.vue": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "mwtransportservice.2cb1f7ac.svg",
      "winenmore.2620196f.svg"
    ],
    "css": [],
    "file": "sponsors.c979b869.js",
    "imports": [
      "_cookie.1b8f798e.js",
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/sponsors.vue"
  },
  "sponsors.5f5576a7.css": {
    "file": "sponsors.5f5576a7.css",
    "resourceType": "style"
  },
  "mwtransportservice.2cb1f7ac.svg": {
    "file": "mwtransportservice.2cb1f7ac.svg",
    "resourceType": "image",
    "mimeType": "image/svg+xml"
  },
  "winenmore.2620196f.svg": {
    "file": "winenmore.2620196f.svg",
    "resourceType": "image",
    "mimeType": "image/svg+xml"
  },
  "pages/vereniging.css": {
    "resourceType": "style",
    "file": "vereniging.2654afbb.css",
    "src": "pages/vereniging.css"
  },
  "pages/vereniging.vue": {
    "resourceType": "script",
    "module": true,
    "css": [],
    "file": "vereniging.49827e7d.js",
    "imports": [
      "_cookie.1b8f798e.js",
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/vereniging.vue"
  },
  "vereniging.2654afbb.css": {
    "file": "vereniging.2654afbb.css",
    "resourceType": "style"
  }
};

export { client_manifest as default };
//# sourceMappingURL=client.manifest.mjs.map
