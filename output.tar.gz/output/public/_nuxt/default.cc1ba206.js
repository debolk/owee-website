import{_ as t,l as r,S as n,k as o}from"./entry.224d4a7d.js";const s={};function a(e,c){return o(),r("div",null,[n(e.$slots,"default")])}const _=t(s,[["render",a]]);export{_ as default};
